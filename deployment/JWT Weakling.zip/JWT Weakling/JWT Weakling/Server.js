const express = require("express");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const app = express();

const SECRET = "password";

app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"));
});

app.post("/login", (req, res) => {
    const username = req.body.username || "guest";

    const token = jwt.sign(
        { user: username, role: "user" },
        SECRET,
        { algorithm: "HS256" }
    );

    res.send(`
        <h2>Welcome, ${username}</h2>
        <p>Your JWT token:</p>
        <textarea style="width:500px; height:150px;">${token}</textarea>
        <br><br>
        <a href="/admin?token=${token}">Go to Admin Panel</a>
    `);
});

app.get("/admin", (req, res) => {
    const token = req.query.token;

    try {
        const decoded = jwt.verify(token, SECRET);

        if (decoded.role !== "admin") {
            return res.send("<h3>Access denied. Admins only.</h3>");
        }

        const flag = fs.readFileSync("flag.txt", "utf8");
        res.send(`<h1>Zero Day Flag:</h1><pre>${flag}</pre>`);
    } catch (err) {
        res.send("<h3>Invalid token.</h3>");
    }
});

app.listen(3000, () => console.log("Server running on port 3000"));
