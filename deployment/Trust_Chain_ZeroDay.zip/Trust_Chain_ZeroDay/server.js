const express = require("express");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const app = express();

const SECRET = "trustchainsecret";

app.use(express.json());

// issue JWT
app.get("/login", (req,res)=>{
  const token = jwt.sign({user:"guest", role:"user"}, SECRET);
  res.json({token});
});

// protected admin route
app.get("/admin", (req,res)=>{
  const token = req.headers.authorization?.split(" ")[1];
  const roleHeader = req.headers["x-role"];

  try {
    const decoded = jwt.verify(token, SECRET);

    // ❌ logic flaw: header overrides JWT
    if(roleHeader === "admin"){
      const flag = fs.readFileSync("flag.txt","utf8");
      return res.send("Welcome admin!<br><pre>"+flag+"</pre>");
    }
    res.status(403).send("Access denied");
  } catch {
    res.status(401).send("Invalid token");
  }
});

app.get("/", (req,res)=>{
  res.sendFile(__dirname + "/views/index.html");
});

app.listen(3000, ()=>console.log("Trust Chain running on port 3000"));
