const express = require("express");
const app = express();
const fs = require("fs");

app.use(express.json());
app.use(express.static("views"));

const UNLOCK_TIME = 2000000000; // far future

app.get("/api/check", (req, res) => {
  const clientTime = parseInt(req.headers["x-time"] || "0");
  if (clientTime > UNLOCK_TIME) {
    return res.json({ unlocked: true, flag: fs.readFileSync("flag.txt","utf8") });
  }
  res.json({ unlocked: false, message: "Too early!" });
});

app.listen(3000, ()=>console.log("Time Capsule running on port 3000"));
