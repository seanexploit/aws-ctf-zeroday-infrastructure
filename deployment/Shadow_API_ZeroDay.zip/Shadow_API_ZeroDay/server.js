const express = require("express");
const fs = require("fs");
const app = express();

app.use(express.static("public"));
app.use(express.json());

// Public API
app.get("/api/profile", (req,res)=>{
  res.json({user:"guest", role:"user"});
});

// Hidden internal API (vulnerability)
app.get("/api/internal/debug", (req,res)=>{
  const flag = fs.readFileSync("flag.txt","utf8");
  res.json({
    status: "debug",
    environment: "production",
    secret: "INTERNAL_API_EXPOSED",
    flag: flag
  });
});

app.get("/", (req,res)=>{
  res.sendFile(__dirname + "/views/index.html");
});

app.listen(3000, ()=>console.log("Shadow API running on port 3000"));
